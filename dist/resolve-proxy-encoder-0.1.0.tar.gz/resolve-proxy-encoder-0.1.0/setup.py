# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['resolve_proxy_encoder',
 'resolve_proxy_encoder.settings',
 'resolve_proxy_encoder.worker',
 'resolve_proxy_encoder.worker.tasks',
 'resolve_proxy_encoder.worker.tasks.standard']

package_data = \
{'': ['*'], 'resolve_proxy_encoder': ['assets/*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'celery>=5.1.2,<6.0.0',
 'ffmpy>=0.3.0,<0.4.0',
 'icecream>=2.1.1,<3.0.0',
 'notify-py>=0.3.3,<0.4.0',
 'pydantic>=1.8.2,<2.0.0',
 'pyfiglet>=0.8.post1,<0.9',
 'redis>=3.5.3,<4.0.0',
 'rich>=10.12.0,<11.0.0',
 'typer>=0.4.0,<0.5.0',
 'win10toast>=0.9,<0.10']

entry_points = \
{'console_scripts': ['rprox = resolve_proxy_encoder.cli:main']}

setup_kwargs = {
    'name': 'resolve-proxy-encoder',
    'version': '0.1.0',
    'description': 'Transcode source media in DaVinci Resolve using multiple machines. Great for quickly creating proxies without interrupting work.',
    'long_description': None,
    'author': 'Caleb Trevatt',
    'author_email': 'in03@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6.2,<3.7',
}


setup(**setup_kwargs)
