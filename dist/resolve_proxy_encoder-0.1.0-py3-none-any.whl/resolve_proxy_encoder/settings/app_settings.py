#!/usr/bin/env python3.6

import os
import shutil
import webbrowser
from pathlib import Path

import typer
import yaml

from resolve_proxy_encoder.helpers import get_rich_logger, app_exit

# Hardcoded because we haven't loaded user settings yet
logger = get_rich_logger("WARNING")

DEFAULT_SETTINGS_FILE = os.path.join(os.path.dirname(__file__), "default_settings.yml")
USER_SETTINGS_FILE = os.path.join(
    Path.home(), ".config", "resolve_proxy_encoder", "user_settings.yml"
)


def get_default_settings():
    """Load default settings from yaml"""

    with open(os.path.join(DEFAULT_SETTINGS_FILE)) as file:
        return yaml.safe_load(file)


def get_user_settings():
    """Load user settings from yaml"""

    with open(os.path.join(USER_SETTINGS_FILE)) as file:
        return yaml.safe_load(file)


def ensure_settings():
    """ Make sure all require settings exist at user config location """

    def _ensure_file():
        """Copy default settings to user settings if it doesn't exist"""

        if not os.path.exists(USER_SETTINGS_FILE):

            if typer.confirm(
                f"No user settings found at path {USER_SETTINGS_FILE}\n"
                + "Load defaults now for adjustment?"
            ):

                # Create dir, copy file, open
                try:
                    os.makedirs(os.path.dirname(USER_SETTINGS_FILE))
                except FileExistsError:
                    typer.echo("Directory exists, skipping...")
                except OSError:
                    typer.echo("Error creating directory!")
                    app_exit(1)

                shutil.copy(DEFAULT_SETTINGS_FILE, USER_SETTINGS_FILE)
                typer.echo(f"Copied default settings to {USER_SETTINGS_FILE}")
                typer.echo("Please customize as necessary.")
                webbrowser.open(USER_SETTINGS_FILE)  # Technically unsupported method
            
            app_exit(0)


    def _ensure_keys():
        """Copy defaults for any missing keys if they don't exist"""
            
        user_settings = get_user_settings()
        default_settings = get_default_settings()

        # Add missing keys
        for key in default_settings:
            if key not in user_settings:
                logger.warning(f"Adding missing key '{key}' to user settings")
                user_settings[key] = default_settings[key]

        # Warn unsupported keys
        for key in user_settings:
            if key not in default_settings:
                logger.warning(f"Found unsupported key '{key}' in user settings")

        with open(USER_SETTINGS_FILE, "w") as file:
            yaml.dump(user_settings, file)

    _ensure_file()
    _ensure_keys()


# Perform on import
ensure_settings()
